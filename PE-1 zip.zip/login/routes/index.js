const express = require("express");
const router = express.Router();
const bcrypt = require('bcryptjs');
const passport = require('passport');
const { ensureAuthenticated } = require('../config/auth');

// welcome page 
router.get('/', (req, res) => res.render("welcome"));


// User model
const User = require('../models/User');



//Dashboard 
router.get('/dashboard', ensureAuthenticated, (req, res) =>
    res.render('dashboard', {
        name: req.user.name
    }));


// dashboard handle
// router.post('/dashboard', (req, res) => {

//     const { Query } = req.body;

//     User.findOne({Query:Query})
//         .then(user =>{
//             const newUser = new User({
//                 Query
//           });
      
//           // Hash password
//           bcrypt.genSalt(10, (err, salt) =>
//                 bcrypt.hash(newUser.Query, salt, (err, hash) => {
//                       if (err) throw err;
//                       //set password to hashed
//                       newUser.Query = hash;
//                       // save user
//                       newUser.save()
//                       .then(user => {
                        
//                         res.redirect('/users/login');
//                   })
//                   .catch(err => console.log(err));
                     
//                 }))
//         })


// });


module.exports = router;

