module.exports={
      MongoURI: 'mongodb+srv://mangeshJ:Mangesh12345@cluster0.uyxbiek.mongodb.net/?retryWrites=true&w=majority'
}